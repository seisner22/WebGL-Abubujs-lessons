#!/bin/bash

gvim app/main.js app/shaders/*.* index.html Abubu/*.* # Abubu/shaders/*.*
